CleanPaste v0.1 — Clean up pasted text in one click.

WHAT IT IS
A single HTML file. Double-click to open in any browser — no install,
no account, no internet needed. Everything runs locally; your text is
never uploaded.

WHAT IT DOES
- Merges extra blank lines
- Trims leading/trailing spaces on every line (optional)
- Removes extra spaces between Chinese characters (optional)
- Shows before/after character and word counts
- Copy the result, or download it as a .txt file

HOW TO USE
1. Open text-cleaner.html in your browser.
2. Paste your messy text into the left box.
3. Click the clean button.
4. Copy the result or download it as .txt.

LICENSE
Personal use. You may use it on as many of your own computers as you like.
Do not redistribute or resell the file itself.

Seller: Alex Lin
Support: fishdp@proton.me
